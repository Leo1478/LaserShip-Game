import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

class GameLoop {

    //objects
    Output output;
    JFrame j;
    KeyListener listener;

    LaserShip l;
    GameLoop g;
    Menu m = new Menu();
    SinglePlayer single = new SinglePlayer();
    MultiPlayer multi = new MultiPlayer();

    static int x = 0;


    //main game loop for everything
    void gameLoop() {

        init();

        while (GameVariables.inGame) {

            GameVariables.frame++;
            System.out.println(GameVariables.frame);


            if (GameVariables.menu) {


                m.menuLoop();


            }


            if (GameVariables.single) {
                single.SingleLoop();

            }


            if (GameVariables.multi) {

                multi.MultiLoop();

            }


            j.repaint();
            delay(10);


        }

    }

    void init() {

        settings();

    }

    void settings() {

        output = new Output();

        j = new JFrame();
        j.getContentPane().add(BorderLayout.CENTER, output);
        j.setTitle("Animation");
        j.setSize(1500, 1000);
        j.setVisible(true);
        j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Output o = new Output();
        j.add(o);


    }

    void delay(int time) {
        try {
            Thread.sleep(time);
        } catch (Exception exc) {

        }
    }


    class Output extends JPanel {

        Output() {

            KeyListener listener = new KeyInput();
            addKeyListener(listener);
            setFocusable(true);

        }

        @Override
        public void paintComponent(Graphics g) {

            super.paintComponent(g);

            if (GameVariables.menu) {

                m.draw(g);
            }
            if (GameVariables.single) {

                single.draw(g);
            }
            if (GameVariables.multi) {

                multi.draw(g);
            }


        }


    }


    private class KeyInput implements KeyListener {


        @Override
        public void keyPressed(KeyEvent e) {

            m.keys(e, true);

        }

        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override
        public void keyReleased(KeyEvent e) {

            m.keys(e, false);

        }


    }


}
