

class Player2Ship {
}
