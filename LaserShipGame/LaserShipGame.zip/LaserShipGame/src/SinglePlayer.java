import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

class SinglePlayer extends JPanel implements KeyListener {


    GameLoop g;
    Menu m;


    void SingleLoop() {


    }


    void draw(Graphics g) {


    }


    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

}






