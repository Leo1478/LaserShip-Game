class LaserShip {


    public static void main(String[] args){

        new GameLoop().gameLoop();


    }


}
