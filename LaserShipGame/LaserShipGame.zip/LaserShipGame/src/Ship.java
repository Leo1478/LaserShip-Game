
class Ship {
}
