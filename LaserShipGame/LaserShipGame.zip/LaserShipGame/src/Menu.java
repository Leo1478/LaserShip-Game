import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.KeyEvent;


class Menu extends JPanel implements KeyListener {


    LaserShip l;
    GameLoop g;




    void menuLoop() {

        if(GameVariables.up){
            System.out.println("up");

        }

        GameLoop.x ++;



    }


    void draw(Graphics g) {

        g.setColor(Color.blue);
        g.fillRect(GameLoop.x, 200, 200, 200);
    }


    @Override
    public void keyPressed(KeyEvent e) {



    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    //use parameter true for keyPressed, false for keyReleased
    void keys(KeyEvent e, boolean bool){

        if (e.getKeyCode() == KeyEvent.VK_UP) {
            GameVariables.up = bool;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            GameVariables.down = bool;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            GameVariables.left = bool;
        }
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            GameVariables.right = bool;
        }

    }


}
