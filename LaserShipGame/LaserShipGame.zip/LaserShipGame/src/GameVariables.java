public class GameVariables {

    static boolean inGame = true;
    static boolean menu = true;
    static boolean single = false;
    static boolean multi = false;

    static boolean up = false;
    static boolean down = false;
    static boolean left = false;
    static boolean right = false;

    static int frame = 0;

}
